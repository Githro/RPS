package rps.bll.player;

/**
 * Player type
 *
 * @author smsj
 */
public enum PlayerType {
    Human,
    AI
}
