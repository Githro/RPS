package rps.bll.game;

/**
 * Helps to determine win or tie in the game
 *
 * @author smsj
 */
public enum ResultType {
    Win,
    Tie
}
